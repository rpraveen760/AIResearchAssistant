import { E, b, c, l, m, p, a, s } from "./2.B3L4zow3.js";
export {
  E as Embed,
  b as changeLocale,
  c as create_components,
  l as language_choices,
  m as mount_css,
  p as prefix_css,
  a as process_langs,
  s as setupi18n
};
